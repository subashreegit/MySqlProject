SELECT * FROM sakila.actor;
SELECT * FROM sakila.actor where actor_id in ( '12041984', '120419841', '120419844');
Select * from sakila.actor ORDER BY CREATE_TIMESTAMP DESC;
Select * from sakila.actor where first_name= 'ERWERBE' ORDER BY CREATE_TIMESTAMP DESC;
SELECT * FROM sakila.actor where protokoll LIKE  ('%Organgesellschaft%')ORDER BY TIME_STAMP desc;
Select * from sakila.actor  WHERE actor_id= '120419844' ORDER BY CREATE_TIMESTAMP DESC;
select z.*, m.FACHL_VERFUEGT_AT from Actor.zustaendigkeit_rm z 
join Actor.basis_zustaendigkeit_map_rm m on z.list_id=m.zustaendigkeit_list_rm_id 
join Actor.basis_rm b on m.basis_rm_id=b.id
join Actor.grinfo_rm g on g.basis_id=b.id 
join Actor.vetto_rm v on v.grinfo_id=g.id 
join Actor.meta_rm m on m.id=z.meta_id
where v.ust_id_nr='DE312349393';

select * from Actor.umsatzdaten_l1_rm
where verkaeufer_ms = 'DK'
and kaeufer_ust_id_nr = 'DE312350098';

Select * from Actor.ed_bericht where ((USTIDNR in('DE312349385')) AND ( ORGAN_TRAEGER in ('DE312349328'))) order by ERSTELLUNGSDATUM desc;
Select * from Actor.ed_bericht where USTIDNR in('DE312349867') order by ERSTELLUNGSDATUM desc;
Select * from surya.Status_RM where LIST_id IN(select GRINFO_ID from sivakumar.vetto_RM where UST_ID_NR in (select PKEY from sivakumar.vetto  where correlation_id in ( '120419845' )));
select * from sivakumar.ORGANSCHAFT_RM  where LIST_id in (select GRINFO_ID from sivakumar.vetto_RM where UST_ID_NR in (select PKEY from sivakumar.vetto  where correlation_id in ( '120419842','120419841', '12041984')));